#  Format of the directives file
#
#             $PYTHON=python
#             $TESTSDIR=../TESTS/
#             $DELETETEMPS=yes                    (delete temporary files?)
#             $OS=windows                  (can be linux or mac)
#             progname inputfile comparisonoutputfile
#
#   The inputfile may be *, which means there is none.
#   The testdir will be prepended to each inputfile and each comparisonoutputfile.
#
#   The command that is run is either:
#
#            python < inputfile > temp_output_N.txt
#                Then we compare temp_output_N.txt against comparisonoutputfile
#
#    or if inputfile is *
#            python > temp_output_N.txt
#                Then we compare temp_output_N.txt against comparisonoutputfile
#
#   The temp output files are deleted after running unless $DELETE is no

import sys
import os, os.path
import traceback

PYTHONCMD = "python "
DELETETEMPS = True
TESTDIR = ""
OS="windows"

def compare(filename1, filename2):
     rets = ""

     with open(filename1) as f:
         text1 = f.read()
     lines1 = text1.split("\n")
     numlines1 = len(lines1)
     rets += ("FILE 1: " + filename1 + "    " + str(numlines1) + " lines, " + str(len(text1)) + " bytes.")

     with open(filename2) as f:
         text2 = f.read()
     lines2 = text2.split("\n")
     numlines2 = len(lines2)
     rets += ("FILE 2: " + filename2 + "    " + str(numlines2) + " lines, " + str(len(text2)) + " bytes.")

     rets += ("\n------------------------comparison of content lines---------------------------\n")

     if text1.strip() == text2.strip():
          rets += ("***No differences! ***")
          status_code = 0

     else:
          for i in range(0,min(len(lines1), len(lines2))):
               if lines1[i] != lines2[i]:
                   rets += (str(i+1)+".  " + lines1[i] + "\n     " + lines2[i] + "\n")
          status_code = 1

     return (status_code, rets)

def main(directive_filename):
     global TESTDIR, PYTHONCMD, DELETETEMPS, OS

     if len(directive_filename) == 0: 
          directive_filename = input("Where is the file containing the testing directives? ")
          if len(directive_filename) == 0: sys.exit()

     with open(directive_filename) as f:
          directives = f.read()

     verbose = input("Do you want verbose output? (y/n)") == "y"

     testnum =1
     numfailed = 0
     
     summary = ""          # a string that holds testing summary
     verbose_all = ""   # all the verbose outputs

     actual_tests = []
     for line in directives.split("\n"):
          if line.startswith("$"): 
                if line.startswith("$PYTHON="):
                     PYTHONCMD = line[8:].strip() + " "
                elif line.startswith("$DELETETEMPS=no"):
                     DELETETEMPS = False
                elif line.startswith("$TESTDIR="):
                     TESTDIR = line[9:]
                     if OS=="windows":
                         TESTDIR = TESTDIR.replace("/", "\\")    # just make sure!
                     else:
                         TESTDIR = TESTDIR.replace("\\", "/")
          elif line.strip() == "" or line.startswith("#"):
                continue
          else:
                actual_tests.append(line)

     print("TESTDIR="+TESTDIR)
     print("PYTHONCMD="+PYTHONCMD)
     print("DELETING TEMPORARY FILES? "+str(DELETETEMPS))

     for testdirective in actual_tests:
          if len(testdirective.strip()) == 0: continue
          pieces = testdirective.split(" ")
          if len(pieces) != 3:
                print("ERROR:  directive line is malformed:   "+testdirective)
                continue
          summary += testdirective + "      "

          outputname = "temp_output_" + str(testnum) + ".txt"
          # the -B option suppresses making the __pycache__ directory or the .pyc files

          testprogname = pieces[0]
          inputfilename = pieces[1]

          if TESTDIR != "":
               inputfilename = TESTDIR + inputfilename
               comparisonoutputname = TESTDIR + pieces[2]
               if OS=="windows":
                    os.system("copy " + TESTDIR + testprogname + " .")
               else:
                    os.system("cp " + TESTDIR + testprogname + " .")
          else:
               comparisonoutputname = pieces[2]
 
          if pieces[1] == "*":
               runstring = PYTHONCMD + " -B " + testprogname + " > " + outputname
          else:
               runstring = PYTHONCMD + " -B " + testprogname + " < " + inputfilename + " > " + outputname
          try:
               print("RUNNING: " + runstring)
               os.system(runstring)
               code, rets = compare(outputname, comparisonoutputname)
               if code == 0:
                    summary += "  SUCCESS!\n"
               else:
                    summary += "  >>FAILURE<<<\n"
                    numfailed += 1
               verbose_all += rets + "\n\n\n"
               if DELETETEMPS:
                    if OS=="windows":       # delete the temporary output file
                         os.system("del " + outputname)     
                    else:
                         os.system("rm " + outputname)
                    if TESTDIR != "":            # delete the temporary programs, too
                         if OS=="windows":
                              os.system("del " + testprogname)     
                         else:
                              os.system("rm " + testprogname)
          except Exception as e:
               summary += "  RUNTIME CRASH !!!\n"
               tb = traceback.format_exc()
               print("Caught a run-time error and recovered from it.")
               print(e.__class__.__name__, end=", ")
               print(e)
               print(tb)
          testnum += 1

     numtests = testnum-1
     numpassed =numtests-numfailed
     executive = "------------------------------------------\n"
     executive += "Num tests: " + str(numtests) + "\n"
     executive += "Num passed: " + ("%2d %3.0f%%\n" % (numpassed, numpassed / numtests * 100))
     executive += "Num failed: " + ("%2d %3.0f%%\n" % (numfailed, numfailed/ numtests * 100))

     executive += "\n\n" + summary
     if verbose:
          executive += "\n\n==================================================\n"
          executive += verbose_all

     print(executive)

#=======================================================================
if len(sys.argv) == 1:
     main("")
else:
     main(sys.argv[1])