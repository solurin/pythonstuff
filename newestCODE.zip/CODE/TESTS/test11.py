from hashmap import *

map = HashMap(10)
#map.debug = True

map.put("john", 57)
map.put("andrew", 29)
map.put("albert", 555)
map.delete("andrew")
map.put("folly", 11)    # reuse andrew's tombstone

print(map.display())

print("Does john exist?", map.exists("john"))
print("Does andrew exist?", map.exists("andrew"))
print("Does luke exist?", map.exists("luke"))
