from hashmap import *

map = HashMap(25)
map.debug = True

map.put("Mark", "Beethoven")
map.info()

print(map.get("Mark"))

map.put("Mark", "Mozart")
map.put("Kathy", "BeeGees")

print(map.get("Mark"))
print(map.get("Kathy"))

map.put("Naqk", "Silly")

map.info()

print(map.get("Naqk"))

print(map.display())