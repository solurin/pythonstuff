from hashmap import *

map = HashMap(100)

print("Mark hashes to ",map.hash("Mark"))
print("Kathy hashes to ",map.hash("Kathy"))