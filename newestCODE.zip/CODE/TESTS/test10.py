from hashmap import *

map = HashMap(10)
#map.debug = True

map.put("john", 57)
map.put("andrew", 29)
map.put("albert", 555)
map.delete("andrew")
map.put("folly", 11)    # reuse andrew's tombstone

print(map.display())

print(map.getKeys())
print(map.getValues())

map.clear()
print(map.display())