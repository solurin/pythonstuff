from hashmap import *

map = HashMap(100)
map.debug = True

map.put("Mark", "Beethoven")
map.info()

print(map.get("Mark"))