from hashmap import *

map = HashMap(100)
map.debug = True

map.put("Mark", "Beethoven")
map.info()

print(map.get("Mark"))

map.put("Mark", "Mozart")
map.put("Kathy", "BeeGees")

print(map.get("Mark"))
print(map.get("Kathy"))

map.delete("Mark")
print(map.get("Mark"))
print(map.get("Kathy"))