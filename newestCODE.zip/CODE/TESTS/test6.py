from hashmap import *

map = HashMap(10)
#map.debug = True

map.put("john", 57)
map.put("andrew", 29)

print(map.display())

map.delete("john")

print(map.display())

print("Getting andrew")
print(map.get("andrew"))

map.put("john", 44)

print(map.display())