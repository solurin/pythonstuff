from hashmap import *

map = HashMap(10)
#map.debug = True

map.put("john", "cat")
map.put("andrew", "dog")
map.put("albert", "cat")
map.put("kathy", "dog")

print(map.display())

print("The following have cats:", map.findValue("cat"))
print("The following have snakes:", map.findValue("snake"))
print("The following have dogs:", map.findValue("dog"))
