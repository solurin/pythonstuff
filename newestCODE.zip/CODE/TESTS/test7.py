from hashmap import *

map = HashMap(10)
#map.debug = True

map.put("john", 57)
map.put("andrew", 29)
map.delete("john")

print(map.display())

map.put("albert", 555)

print(map.display())

