from hashmap import *
import traceback

map = HashMap(10)
#map.debug = True

map.put("john", 57)
map.put("andrew", 29)
map.put("albert", 555)
map.put("terri", 99)

print(map.display())

try:
	map.put("sissy", 23)
except Exception as e:
   #tb = traceback.format_exc()
   print("Caught a run-time error and recovered from it.")
   print(e.__class__.__name__, end=", ")
   print(e)
   #print(tb)
