from Array import *

class Object:
	def __init__(self, key, value):
		self.key = key
		self.value = value
	def __str__(self):
		return "key=" + str(key)+"    value="+str(value)

if __name__ == "__main__":
	mylist = Array(10)
	mylist[0] = Object("cat", 4739)

	print(mylist[0].key)
	print(mylist[0].value)