#--------------------topcode, do not change!--------------------
from  tkinter import *
import tkinter.messagebox as box
import tkinter.simpledialog as simpledialog
import tkinter.filedialog as filedialog
import sys
import math
import functools


#--------------------common helper functions, do not change!--------------------
def settext(widget, newtext):
	'''
		This is how you change text in a widget.  What it does varies depending on the widget.
		Always give a string as the second parameter, even if you want to just put a number in it.
	'''
	if type(widget).__name__ == 'ScrolledList':               # have to do this because ScrolledList may not have been included
		widget.listbox.delete(0,END)
		if type(newtext) == list:
			for string in newtext:
				widget.listbox.insert(END,string)
		elif type(newtext) == str:
			for string in newtext.split('\n'):
 				widget.listbox.insert(END,string)

	elif type(widget).__name__ == 'ScrolledText':               # have to do this because ScrolledText may not have been included
		widget.text.delete('1.0', END)
		widget.text.insert('1.0', newtext)
		widget.text.mark_set(INSERT, '1.0')

	elif type(widget) == Text:
		widget.delete('1.0', END)
		widget.insert('1.0', newtext)

	elif type(widget) == Entry:
		widget.delete(0,END)
		widget.insert(0,newtext)

	elif type(widget) == Label:
		widget['text'] = newtext

	elif type(widget) == Button:
		widget.config(text=newtext)

	elif type(widget) == Checkbutton:
		widget.config(text=newtext)

	elif type(widget) == Scale:
		widget['label'] = newtext

	elif type(widget) == Listbox:
		widget.delete(0,END)
		if type(newtext) == list:
			for string in newtext:
				widget.insert(END,string)
		elif type(newtext) == str:
			for string in newtext.split('\n'):
				widget.insert(END,string)

	elif type(widget) == Menubutton:
		widget['text'] = newtext

def gettext(widget):
	'''
		This gets the contents of a widget and returns a string.  If it is a label, it just returns the label text.
		If it is a button, it returns the text on the face of the button.  If it is a list or checkbox, it returns the
		string that is currently selected.
	'''
	if type(widget).__name__ == 'ScrolledList':
		return list(widget.listbox.get(0,END))

	elif type(widget).__name__ == 'ScrolledText':
		return widget.text.get('1.0', END+'-1c')

	elif type(widget) == Text:
		return widget.get('1.0', END+'-1c')

	elif type(widget) == Entry:
		return widget.get()

	elif type(widget) == Label:
		return widget.cget('text')

	elif type(widget) == Button:
		return widget['text']

	elif type(widget) == Checkbutton:
		return widget.cget('text')

	elif type(widget) == Scale:
		return widget['label']

	elif type(widget) == Listbox:
		return list(widget.get(0,END))

	elif type(widget) == Menubutton:
		return widget['text']

def appendtext(widget, newtext):
	'''
		This sets the text by first getting the current text and appending to the end.
		It does not automatically insert a newline or any spaces.  You should do that yourself, if desired.
	'''
	current_text = gettext(widget)
	settext(widget, current_text + newtext)

def popup(msg):
	'''
		Use this to display a quick message to the user.  Just give it a string.
	'''
	box.showinfo('msg', msg)

def askforstring(prompt):
	'''
		Use this to get a string from the user.  The prompt is what is displayed on the dialog box.
	'''
	return simpledialog.askstring('request for input', prompt)

def askforyesno(prompt):
	'''
		Use this to get a String response from the user.  It is either yes or no.
		Notice, the type of the returned object is str, not boolean!
		The prompt is what is displayed on the dialog box.
	'''
	return box.askquestion('request for yes/no', prompt)

def getselected(somelistbox):
	'''
		Use this to get the currently selected text from a listbox.
	'''
	if type(somelistbox) == Listbox:
		try:
			return somelistbox.get(somelistbox.curselection()[0])
		except:
			return ''
	else:
		return somelistbox.getselected()

def readFile(filename):
	'''
		Read contents of file whose name is filename, and return it.
		Return empty string on error.
	'''
	try:
		f = open(filename,'r')
		text = f.read()
		f.close()
		return text
	except:
		print('Error in readfile:  filename='+filename)
		return ''

def writeFile(filename, text):
	'''
		Write contents into file whose name is filename.
		Return False on error, True on success
	'''
	try:
		f = open(filename,'w')
		f.write(text)
		f.close()
		return True
	except:
		print('Error in writefile:  filename='+filename)
		return False

def exists(filename):
	'''
		Return True if file named filename exists
	'''
	return os.path.isfile(filename)


#--------------------modulecode, do not change!--------------------

##%MODULECODE
from hashmap import *
import time
from tkinter.filedialog import askopenfilename,asksaveasfilename,askdirectory

def addOrUpdate():
	newkey = gettext(newKeyTF)
	newvalue = gettext(newValueTF)
	if len(newvalue) == 0:
		newvalue = "1"
	try:
		myhashmap.put(newkey, newvalue)
		settext(newKeyTF, "")
		settext(newValueTF, "")
		settext(hashkey1L, str(myhashmap.hash(newkey)))
		newKeyTF.focus_set()
		display()
	except ValueError:
		popup("collision area is full!")

def find():
	thekey = gettext(oldKeyTF)
	settext(findKeyL, str(myhashmap.hash(gettext(oldKeyTF))))
	foundkey = myhashmap.get(thekey)
	if foundkey == None:
		settext(msg1L, "Key not found")
		settext(oldValueTF, "")
	else:
		settext(msg1L, "")
		settext(oldValueTF, foundkey)

def delete():
	thekey = gettext(delKeyTF)
	settext(delKeyL, str(myhashmap.hash(gettext(delKeyTF))))
	foundkey = myhashmap.delete(thekey)
	settext(delKeyTF, "")
	display()

def newMap():
	if gettext(newSizeTF) == "":
		popup("You need to add a size of the array")
		return
	global myhashmap
	temp = gettext(pctCollisionsTF)
	if temp.endswith("%"): temp = temp[0:-1]
	myhashmap = HashMap(int(gettext(newSizeTF)), int(temp))
	#settext(newSizeTF, "")
	display()

def check():
	newkey = gettext(tempKeyTF)
	index = myhashmap.hash(newkey)
	settext(showKeyL, str(index))

def showAllKeys():
	keylist = myhashmap.getKeys()
	settext(keysTA, "\n".join(keylist))
	settext(numKeysL, str(len(keylist)))

def showAllValues():
	valuelist = myhashmap.getValues()
	settext(valuesTA, "\n".join(valuelist))
	settext(numValuesL, str(len(valuelist)))

def makeSample():
	commands = "Kathy=dog;Mark=cat;Sally=cat;Anthony=dog;Susan=lizard;George=frog;Alley=iguana;" + \
		    "Axel=gorilla;Beatrice=snake"
	for line in commands.split(";"):
		pieces = line.split("=")
		settext(newKeyTF, pieces[0])
		settext(newValueTF, pieces[1])
		add()
	display()
	showAllKeys()
	showAllValues()

def display():
	settext(bigTA, myhashmap.display())

def post_initialization():
	global myhashmap
	myhashmap = HashMap(25)
	display()

def loadCommands():
	fullpath = askopenfilename()
	if fullpath is None or fullpath == "": return
	settext(filenameTF, fullpath)
	settext(commandsTA, readFile(fullpath))

def saveCommands():
     fullpath = gettext(filenameTF)
     if len(fullpath.strip()) == 0:
          fullpath = asksaveasfilename()
          settext(filenameTF, fullpath)
     fp = open(fullpath, "w")
     fp.write(gettext(commandsTA))
     fp.close()
     box.showinfo('Saved!',"Your commands were saved to:\n"+fullpath)

def runall():
	for line in gettext(commandsTA).split("\n"):
		runOne(line)

def runOne(command):
	if command.startswith("put "):
		pieces=command[4:].split(" ")
		myhashmap.put(pieces[0], pieces[1])
		display()
	elif command.startswith("get "):
		found = myhashmap.get(command[4:])
		if found == None:
			found = "NOT FOUND!"
		append(resultsTA, command)
		append(resultsTA, "    " + found)
	elif command.startswith("delete "):
		myhashmap.delete(command[7:])
		display()
	elif command.startswith("new "):
		size = int(command[4:])
		settext(newSizeTF, str(size))
		myhashmap.delete(command[4:])
		newMap()
		display()
	elif command == "pause":
		popup("Dismiss to continue")

def showSample(whichSample):
	s = ""
	if whichSample == "sample1":
		s += "put john elephant\nput kathy dog\nput mark cat\nget sally\nget john\n"
		s += "del john\nput donald python\nput minnie mouse"
	elif whichSample == "sample2":
		s += "new 10\nput john 5\nput albert 6\npause\n"
		s += "delete john\nget albert\ndelete albert\nput john 999\n"
		s += "put terri 44"
	settext(commandsTA, s)

def append(ta, what):
	text = gettext(ta)
	if len(text.strip()) == 0:
		settext(ta, what)
	else:
		text += "\n" + what
		settext(ta, text)
##%ENDCODE

def window_init():
     global root
     root=Tk()
     root.geometry("873x582")
     root.configure(background='#ebebeb')
     root.title("Python application")
     canvas = Canvas(bd=0, highlightthickness=0)
     canvas.pack(fill=BOTH, expand=1)
     canvas.bind("<Configure>", resizeMe)

#--------------------internally defined widget classes, do not change!--------------------
class ScrolledText(Frame):
	def __init__(self, parent=None):
		Frame.__init__(self, parent)
		self._makewidgets()

	def _makewidgets(self):
		sbar = Scrollbar(self)
		text = Text(self, relief=SUNKEN)
		sbar.config(command=text.yview)
		text.config(yscrollcommand=sbar.set)
		sbar.pack(side=RIGHT,fill=Y)
		text.pack(side=LEFT,expand=YES,fill=BOTH)
		self.text = text
	
	def settext(self, text=''):
		self.text.delete('1.0', END)
		self.text.insert('1.0', text)
		self.text.mark_set(INSERT, '1.0')

	def gettext(self):
		return self.text.get('1.0', END+'-1c');

	def append(self, text=''):
		self.text.insert(END,text)



#--------------------functions for widget event handlers, do not change!--------------------
def newKeyTF_action_code():
    addOrUpdate()

def newValueTF_action_code():
    addOrUpdate()

def addNewB_action_code():
    addOrUpdate()

def oldKeyTF_action_code():
    find()

def findB_action_code():
    find()

def delKeyTF_action_code():
    delete()

def deleteB_action_code():
    delete()

def newMapB_action_code():
    newMap()

def newSizeTF_action_code():
    newMap()

def fillSampleB_action_code():
    makeSample()

def tempKeyTF_action_code():
    check()

def playHashKeyB_action_code():
    check()

def getKeysB_action_code():
    showAllKeys()

def getAllValuesB_action_code():
    showAllValues()

def infoB_action_code():
    popup(myhashmap.info())

def clearB_action_code():
    myhashmap.clear()
    display()

def runallB_action_code():
    runall()

def loadB_action_code():
    loadCommands()

def saveB_action_code():
    saveCommands()

def getSampleCH_item_code():
    showSample(gettext(getSampleCH))

def getSampleCH_respond(keycode):
     if keycode == 1:
          getSampleCH.config(text='sample1')
          for thing in getSampleCH_varlist:
               thing.set(0)
          getSampleCH_xvar1.set(1)
     if keycode == 2:
          getSampleCH.config(text='sample2')
          for thing in getSampleCH_varlist:
               thing.set(0)
          getSampleCH_xvar2.set(1)
     showSample(gettext(getSampleCH))
def runselectedB_action_code():
    text = commandsTA.text.get(SEL_FIRST, SEL_LAST)
    runOne(text)



#--------------------Menu defs, do not change!--------------------


#--------------------extra class code, you can change this!--------------------
##%EXTRACLASSCODE

##%ENDCODE

def resizeMe(event):
     if 'resize_code' in globals():
          resize_code(event)
def main():
     window_init()
     global Button1_var
     global newKeyTF
     global Button1_var
     global newValueTF
     global addNewB
     global component0BL
     global label1L
     global Button1_var
     global oldKeyTF
     global label2L
     global findB
     global Button1_var
     global oldValueTF
     global label3L
     global component3BL
     global label4L
     global component4BL
     global bigTA
     global label5L
     global Button1_var
     global delKeyTF
     global deleteB
     global label7L
     global label8L
     global newMapB
     global component7BL
     global Button1_var
     global newSizeTF
     global msg1L
     global fillSampleB
     global hashkey1L
     global label9L
     global Button1_var
     global tempKeyTF
     global playHashKeyB
     global label10L
     global label11L
     global showKeyL
     global findKeyL
     global delKeyL
     global component10BL
     global Button1_var
     global pctCollisionsTF
     global label12L
     global keysTA
     global getKeysB
     global getAllValuesB
     global valuesTA
     global numKeysL
     global numValuesL
     global infoB
     global clearB
     global component11BL
     global commandsTA
     global runallB
     global loadB
     global Button1_var
     global filenameTF
     global component16BL
     global resultsTA
     global saveB
     global component17BL
     global getSampleCH_varlist
     global getSampleCH_xvar1
     global getSampleCH_xvar2
     global getSampleCH
     global runselectedB
#--------------------widget making code, do not change anything from here to the end of the file!--------------------
     Button1_var=StringVar()
     Button1_var.set("")
     newKeyTF = Entry(root,width=147, textvariable=Button1_var)
     newKeyTF.place(x=116,y=26, width=147, height=21)
     newKeyTF.config(font=("SansSerif", 10, 'normal'))
     newKeyTF.config(fg=("#000000"))
     newKeyTF.config(bg=("#ffffff"))
     newKeyTF.bind('<Return>', lambda x: newKeyTF_action_code())
     Button1_var=StringVar()
     Button1_var.set("")
     newValueTF = Entry(root,width=147, textvariable=Button1_var)
     newValueTF.place(x=116,y=53, width=147, height=21)
     newValueTF.config(font=("SansSerif", 10, 'normal'))
     newValueTF.config(fg=("#000000"))
     newValueTF.config(bg=("#ffffff"))
     newValueTF.bind('<Return>', lambda x: newValueTF_action_code())
     addNewB = Button(root, text="Add",width=75,height=22,command=addNewB_action_code)
     addNewB.place(x=188,y=76, width=75, height=22)
     addNewB.config(font=("SansSerif", 10, 'normal'))
     addNewB.config(bg=("#ffffff"))
     addNewB.config(fg=("#000000"))
     component0BL = Label(root, text="New Key:",width=71,height=22)
     component0BL.place(x=43,y=26, width=71, height=22)
     component0BL.config(font=("SansSerif", 10, 'normal'))
     component0BL.config(bg=root['bg'])
     component0BL.config(fg=("#000000"))
     label1L = Label(root, text="New Value:",width=71,height=22)
     label1L.place(x=43,y=53, width=71, height=22)
     label1L.config(font=("SansSerif", 10, 'normal'))
     label1L.config(bg=root['bg'])
     label1L.config(fg=("#000000"))
     Button1_var=StringVar()
     Button1_var.set("")
     oldKeyTF = Entry(root,width=147, textvariable=Button1_var)
     oldKeyTF.place(x=116,y=141, width=147, height=21)
     oldKeyTF.config(font=("SansSerif", 10, 'normal'))
     oldKeyTF.config(fg=("#000000"))
     oldKeyTF.config(bg=("#ffffff"))
     oldKeyTF.bind('<Return>', lambda x: oldKeyTF_action_code())
     label2L = Label(root, text="Key:",width=55,height=22)
     label2L.place(x=59,y=141, width=55, height=22)
     label2L.config(font=("SansSerif", 10, 'normal'))
     label2L.config(bg=root['bg'])
     label2L.config(fg=("#000000"))
     findB = Button(root, text="Find",width=69,height=22,command=findB_action_code)
     findB.place(x=194,y=165, width=69, height=22)
     findB.config(font=("SansSerif", 10, 'normal'))
     findB.config(bg=("#ffffff"))
     findB.config(fg=("#000000"))
     Button1_var=StringVar()
     Button1_var.set("")
     oldValueTF = Entry(root,width=147, textvariable=Button1_var)
     oldValueTF.place(x=116,y=190, width=147, height=21)
     oldValueTF.config(font=("SansSerif", 10, 'normal'))
     oldValueTF.config(fg=("#000000"))
     oldValueTF.config(bg=("#ffffff"))
     label3L = Label(root, text="Value:",width=48,height=22)
     label3L.place(x=70,y=190, width=48, height=22)
     label3L.config(font=("SansSerif", 10, 'normal'))
     label3L.config(bg=root['bg'])
     label3L.config(fg=("#000000"))
     component3BL = Label(root, text="New or Change:",width=107,height=19)
     component3BL.place(x=16,y=5, width=107, height=19)
     component3BL.config(font=("SansSerif", 10, 'bold'))
     component3BL.config(bg=root['bg'])
     component3BL.config(fg=("#000000"))
     label4L = Label(root, text="Find:",width=58,height=17)
     label4L.place(x=14,y=117, width=58, height=17)
     label4L.config(font=("SansSerif", 10, 'bold'))
     label4L.config(bg=root['bg'])
     label4L.config(fg=("#000000"))
     component4BL = Label(root, text="------------------------------------------------------------------------",width=299,height=13)
     component4BL.place(x=13,y=102, width=299, height=13)
     component4BL.config(font=("SansSerif", 10, 'normal'))
     component4BL.config(bg=root['bg'])
     component4BL.config(fg=("#000000"))
     bigTA = ScrolledText(root)
     bigTA.place(x=313,y=30, width=273, height=546)
     bigTA.settext("")
     bigTA.text.config(font=("Courier", 10, 'normal'))
     bigTA.text.config(bg=("#ffe5c1"))
     bigTA.text.config(fg=("#000000"))
     label5L = Label(root, text="Key:",width=44,height=22)
     label5L.place(x=67,y=249, width=44, height=22)
     label5L.config(font=("SansSerif", 10, 'normal'))
     label5L.config(bg=root['bg'])
     label5L.config(fg=("#000000"))
     Button1_var=StringVar()
     Button1_var.set("")
     delKeyTF = Entry(root,width=147, textvariable=Button1_var)
     delKeyTF.place(x=116,y=249, width=147, height=21)
     delKeyTF.config(font=("SansSerif", 10, 'normal'))
     delKeyTF.config(fg=("#000000"))
     delKeyTF.config(bg=("#ffffff"))
     delKeyTF.bind('<Return>', lambda x: delKeyTF_action_code())
     deleteB = Button(root, text="Delete",width=69,height=22,command=deleteB_action_code)
     deleteB.place(x=194,y=271, width=69, height=22)
     deleteB.config(font=("SansSerif", 10, 'normal'))
     deleteB.config(bg=("#ffffff"))
     deleteB.config(fg=("#000000"))
     label7L = Label(root, text="Delete:",width=58,height=17)
     label7L.place(x=12,y=228, width=58, height=17)
     label7L.config(font=("SansSerif", 10, 'bold'))
     label7L.config(bg=root['bg'])
     label7L.config(fg=("#000000"))
     label8L = Label(root, text="------------------------------------------------------------------------",width=299,height=13)
     label8L.place(x=13,y=213, width=299, height=13)
     label8L.config(font=("SansSerif", 10, 'normal'))
     label8L.config(bg=root['bg'])
     label8L.config(fg=("#000000"))
     newMapB = Button(root, text="Make New Hashmap",width=141,height=20,command=newMapB_action_code)
     newMapB.place(x=14,y=508, width=141, height=20)
     newMapB.config(font=("SansSerif", 10, 'bold'))
     newMapB.config(bg=("#ffc800"))
     newMapB.config(fg=("#000000"))
     component7BL = Label(root, text="Size:",width=43,height=19)
     component7BL.place(x=162,y=508, width=43, height=19)
     component7BL.config(font=("SansSerif", 10, 'bold'))
     component7BL.config(bg=root['bg'])
     component7BL.config(fg=("#000000"))
     Button1_var=StringVar()
     Button1_var.set("25")
     newSizeTF = Entry(root,width=79, textvariable=Button1_var)
     newSizeTF.place(x=206,y=508, width=79, height=21)
     newSizeTF.config(font=("SansSerif", 10, 'normal'))
     newSizeTF.config(fg=("#000000"))
     newSizeTF.config(bg=("#ffffff"))
     newSizeTF.bind('<Return>', lambda x: newSizeTF_action_code())
     Button1_var.set("25")
     msg1L = Label(root, text="",width=119,height=22)
     msg1L.place(x=12,y=166, width=119, height=22)
     msg1L.config(font=("SansSerif", 10, 'normal'))
     msg1L.config(bg=root['bg'])
     msg1L.config(fg=("#ff0000"))
     fillSampleB = Button(root, text="Fill in with sample",width=150,height=20,command=fillSampleB_action_code)
     fillSampleB.place(x=14,y=552, width=150, height=20)
     fillSampleB.config(font=("SansSerif", 10, 'normal'))
     fillSampleB.config(bg=("#ffffff"))
     fillSampleB.config(fg=("#000000"))
     hashkey1L = Label(root, text="",width=47,height=22)
     hashkey1L.place(x=264,y=26, width=47, height=22)
     hashkey1L.config(font=("SansSerif", 10, 'normal'))
     hashkey1L.config(bg=root['bg'])
     hashkey1L.config(fg=("#ff0000"))
     label9L = Label(root, text="Key:",width=45,height=22)
     label9L.place(x=67,y=331, width=45, height=22)
     label9L.config(font=("SansSerif", 10, 'normal'))
     label9L.config(bg=root['bg'])
     label9L.config(fg=("#000000"))
     Button1_var=StringVar()
     Button1_var.set("")
     tempKeyTF = Entry(root,width=147, textvariable=Button1_var)
     tempKeyTF.place(x=116,y=331, width=147, height=21)
     tempKeyTF.config(font=("SansSerif", 10, 'normal'))
     tempKeyTF.config(fg=("#000000"))
     tempKeyTF.config(bg=("#ffffff"))
     tempKeyTF.bind('<Return>', lambda x: tempKeyTF_action_code())
     playHashKeyB = Button(root, text="Check",width=69,height=22,command=playHashKeyB_action_code)
     playHashKeyB.place(x=194,y=354, width=69, height=22)
     playHashKeyB.config(font=("SansSerif", 10, 'normal'))
     playHashKeyB.config(bg=("#ffffff"))
     playHashKeyB.config(fg=("#000000"))
     label10L = Label(root, text="Check hash:",width=90,height=17)
     label10L.place(x=12,y=310, width=90, height=17)
     label10L.config(font=("SansSerif", 10, 'bold'))
     label10L.config(bg=root['bg'])
     label10L.config(fg=("#000000"))
     label11L = Label(root, text="------------------------------------------------------------------------",width=299,height=13)
     label11L.place(x=13,y=295, width=299, height=13)
     label11L.config(font=("SansSerif", 10, 'normal'))
     label11L.config(bg=root['bg'])
     label11L.config(fg=("#000000"))
     showKeyL = Label(root, text="",width=47,height=22)
     showKeyL.place(x=264,y=331, width=47, height=22)
     showKeyL.config(font=("SansSerif", 10, 'normal'))
     showKeyL.config(bg=root['bg'])
     showKeyL.config(fg=("#ff0000"))
     findKeyL = Label(root, text="",width=47,height=22)
     findKeyL.place(x=264,y=141, width=47, height=22)
     findKeyL.config(font=("SansSerif", 10, 'normal'))
     findKeyL.config(bg=root['bg'])
     findKeyL.config(fg=("#ff0000"))
     delKeyL = Label(root, text="",width=47,height=22)
     delKeyL.place(x=264,y=249, width=47, height=22)
     delKeyL.config(font=("SansSerif", 10, 'normal'))
     delKeyL.config(bg=root['bg'])
     delKeyL.config(fg=("#ff0000"))
     component10BL = Label(root, text="Percentage devoted to collisions:",width=236,height=18)
     component10BL.place(x=14,y=532, width=236, height=18)
     component10BL.config(font=("SansSerif", 10, 'normal'))
     component10BL.config(bg=root['bg'])
     component10BL.config(fg=("#000000"))
     Button1_var=StringVar()
     Button1_var.set("25%")
     pctCollisionsTF = Entry(root,width=33, textvariable=Button1_var)
     pctCollisionsTF.place(x=252,y=532, width=33, height=19)
     pctCollisionsTF.config(font=("SansSerif", 10, 'normal'))
     pctCollisionsTF.config(fg=("#000000"))
     pctCollisionsTF.config(bg=("#ffffff"))
     Button1_var.set("25%")
     label12L = Label(root, text="------------------------------------------------------------------------",width=299,height=13)
     label12L.place(x=13,y=377, width=299, height=13)
     label12L.config(font=("SansSerif", 10, 'normal'))
     label12L.config(bg=root['bg'])
     label12L.config(fg=("#000000"))
     keysTA = ScrolledText(root)
     keysTA.place(x=11,y=419, width=123, height=80)
     keysTA.settext("")
     keysTA.text.config(font=("SansSerif", 10, 'normal'))
     keysTA.text.config(bg=("#ffffff"))
     keysTA.text.config(fg=("#000000"))
     getKeysB = Button(root, text="All Keys",width=69,height=22,command=getKeysB_action_code)
     getKeysB.place(x=11,y=395, width=69, height=22)
     getKeysB.config(font=("SansSerif", 10, 'normal'))
     getKeysB.config(bg=("#ffffff"))
     getKeysB.config(fg=("#000000"))
     getAllValuesB = Button(root, text="All Values",width=69,height=22,command=getAllValuesB_action_code)
     getAllValuesB.place(x=168,y=395, width=69, height=22)
     getAllValuesB.config(font=("SansSerif", 10, 'normal'))
     getAllValuesB.config(bg=("#ffffff"))
     getAllValuesB.config(fg=("#000000"))
     valuesTA = ScrolledText(root)
     valuesTA.place(x=168,y=419, width=123, height=80)
     valuesTA.settext("")
     valuesTA.text.config(font=("SansSerif", 10, 'normal'))
     valuesTA.text.config(bg=("#ffffff"))
     valuesTA.text.config(fg=("#000000"))
     numKeysL = Label(root, text="",width=48,height=22)
     numKeysL.place(x=87,y=395, width=48, height=22)
     numKeysL.config(font=("SansSerif", 10, 'normal'))
     numKeysL.config(bg=root['bg'])
     numKeysL.config(fg=("#0000ff"))
     numValuesL = Label(root, text="",width=48,height=22)
     numValuesL.place(x=244,y=395, width=48, height=22)
     numValuesL.config(font=("SansSerif", 10, 'normal'))
     numValuesL.config(bg=root['bg'])
     numValuesL.config(fg=("#0000ff"))
     infoB = Button(root, text="Info",width=56,height=20,command=infoB_action_code)
     infoB.place(x=230,y=553, width=56, height=20)
     infoB.config(font=("SansSerif", 10, 'bold'))
     infoB.config(bg=("#77e5af"))
     infoB.config(fg=("#000000"))
     clearB = Button(root, text="Clear",width=41,height=21,command=clearB_action_code)
     clearB.place(x=178,y=552, width=41, height=21)
     clearB.config(font=("SansSerif", 10, 'bold'))
     clearB.config(bg=("#ff0000"))
     clearB.config(fg=("#ffff00"))
     component11BL = Label(root, text="Command stream:",width=110,height=24)
     component11BL.place(x=588,y=4, width=110, height=24)
     component11BL.config(font=("SansSerif", 9, 'normal'))
     component11BL.config(bg=root['bg'])
     component11BL.config(fg=("#000000"))
     commandsTA = ScrolledText(root)
     commandsTA.place(x=588,y=30, width=281, height=306)
     commandsTA.settext("")
     commandsTA.text.config(font=("SansSerif", 10, 'normal'))
     commandsTA.text.config(bg=("#ffffff"))
     commandsTA.text.config(fg=("#000000"))
     runallB = Button(root, text="Run all",width=53,height=24,command=runallB_action_code)
     runallB.place(x=777,y=4, width=53, height=24)
     runallB.config(font=("SansSerif", 10, 'normal'))
     runallB.config(bg=("#ffffff"))
     runallB.config(fg=("#000000"))
     loadB = Button(root, text="Load",width=43,height=24,command=loadB_action_code)
     loadB.place(x=831,y=4, width=43, height=24)
     loadB.config(font=("SansSerif", 10, 'normal'))
     loadB.config(bg=("#ffffff"))
     loadB.config(fg=("#000000"))
     Button1_var=StringVar()
     Button1_var.set("")
     filenameTF = Entry(root,width=224, textvariable=Button1_var)
     filenameTF.place(x=589,y=338, width=224, height=22)
     filenameTF.config(font=("SansSerif", 8, 'normal'))
     filenameTF.config(fg=("#000000"))
     filenameTF.config(bg=("#ffffff"))
     component16BL = Label(root, text="Results:",width=70,height=22)
     component16BL.place(x=588,y=365, width=70, height=22)
     component16BL.config(font=("SansSerif", 10, 'normal'))
     component16BL.config(bg=root['bg'])
     component16BL.config(fg=("#000000"))
     resultsTA = ScrolledText(root)
     resultsTA.place(x=589,y=389, width=279, height=187)
     resultsTA.settext("")
     resultsTA.text.config(font=("SansSerif", 10, 'normal'))
     resultsTA.text.config(bg=("#ffffff"))
     resultsTA.text.config(fg=("#000000"))
     saveB = Button(root, text="Save",width=54,height=22,command=saveB_action_code)
     saveB.place(x=815,y=338, width=54, height=22)
     saveB.config(font=("SansSerif", 10, 'normal'))
     saveB.config(bg=("#ffffff"))
     saveB.config(fg=("#000000"))
     component17BL = Label(root, text="The hashmap: * indicates overflow area",width=274,height=22)
     component17BL.place(x=312,y=5, width=274, height=22)
     component17BL.config(font=("SansSerif", 9, 'normal'))
     component17BL.config(bg=root['bg'])
     component17BL.config(fg=("#000000"))
     getSampleCH = Menubutton(root, text='Select sample')
     getSampleCH.place(x=700,y=5, width=76, height=22)
     getSampleCH.config(font=("SansSerif", 8, 'normal'))
     getSampleCH.config(bg=("#ffff00"))
     getSampleCH.config(fg=("#000000"))
     getSampleCH.menu = Menu(getSampleCH, tearoff=0)
     getSampleCH['menu'] = getSampleCH.menu
     getSampleCH_varlist=[]
     getSampleCH_xvar1=IntVar()
     getSampleCH_varlist.append(getSampleCH_xvar1)
     getSampleCH.menu.add_checkbutton(label='sample1',variable=getSampleCH_xvar1, command=functools.partial(getSampleCH_respond, 1))
     getSampleCH_xvar2=IntVar()
     getSampleCH_varlist.append(getSampleCH_xvar2)
     getSampleCH.menu.add_checkbutton(label='sample2',variable=getSampleCH_xvar2, command=functools.partial(getSampleCH_respond, 2))
     getSampleCH.bind("<<ListboxSelect>>", (lambda event: getSampleCH_item_code()))
     runselectedB = Button(root, text="Run selected",width=111,height=22,command=runselectedB_action_code)
     runselectedB.place(x=758,y=362, width=111, height=22)
     runselectedB.config(font=("SansSerif", 9, 'normal'))
     runselectedB.config(bg=("#ffffff"))
     runselectedB.config(fg=("#000000"))


     post_initialization()
     root.mainloop()

if __name__ == '__main__':
     main()

####DIRECTIVES
##%START
##%PROGRAM DATE=Tue, Feb 19, 2019 6:41:39 PM
##%VERSION=PY2
##%CLASS_STYLE=no class
##%WHENWRITTEN=Thu Apr 04 12:45:05 EDT 2019
##%CLASSNAME=gui
##%PACKAGENAME=
##%DIRECTORY=C:/Users/meyer/Desktop/Dropbox/CSC112/LABS/PROJECT3/CODE
##%GUITYPE=Python
##%EXTRAMETHODS=0
##%PROGTYPE=Application
##%TITLEBAR=Python application
##%SAVEMYTEXTAREA=true
##%SNAPSHOTVARLIST=
##%RUNTIMECLASSPATH=
##%BGIMAGENAME=
##%BGIMAGERESIZE=true
##%USEBGIMAGE=true
##%CANRESIZEMAINWINDOW=true
##%MENUS
##%ENDMENU
##%BGCOLOR=235,235,235
##%WIDTH=888
##%HEIGHT=637
##%COMPONENTS
##%COMPONENT 
##%  id=1
##%  type=Label
##%  label=New Key:
##%  varname=component0BL
##%  startpoint=43,76
##%  endpoint=114,98
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=2
##%  type=TextField
##%  label=
##%  varname=newKeyTF
##%  startpoint=116,76
##%  endpoint=263,97
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=addOrUpdate()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=5
##%  type=TextField
##%  label=
##%  varname=newValueTF
##%  startpoint=116,103
##%  endpoint=263,124
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=addOrUpdate()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=6
##%  type=Label
##%  label=New Value:
##%  varname=label1L
##%  startpoint=43,103
##%  endpoint=114,125
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=7
##%  type=Button
##%  label=Add
##%  varname=addNewB
##%  startpoint=188,126
##%  endpoint=263,148
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=addOrUpdate()\n
##%  codeItem=
##%END
##%COMPONENT 
##%  id=10
##%  type=TextField
##%  label=
##%  varname=oldKeyTF
##%  startpoint=116,191
##%  endpoint=263,212
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=find()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=11
##%  type=Label
##%  label=Key:
##%  varname=label2L
##%  startpoint=59,191
##%  endpoint=114,213
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=12
##%  type=Button
##%  label=Find
##%  varname=findB
##%  startpoint=194,215
##%  endpoint=263,237
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=find()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=15
##%  type=TextField
##%  label=
##%  varname=oldValueTF
##%  startpoint=116,240
##%  endpoint=263,261
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=16
##%  type=Label
##%  label=Value:
##%  varname=label3L
##%  startpoint=70,240
##%  endpoint=118,262
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=17
##%  type=Label
##%  label=New or Change:
##%  varname=component3BL
##%  startpoint=16,55
##%  endpoint=123,74
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=bold
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=18
##%  type=Label
##%  label=Find:
##%  varname=label4L
##%  startpoint=14,167
##%  endpoint=72,184
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=bold
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=19
##%  type=Label
##%  label=------------------------------------------------------------------------
##%  varname=component4BL
##%  startpoint=13,152
##%  endpoint=312,165
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=20
##%  type=TextArea
##%  label=
##%  varname=bigTA
##%  startpoint=313,80
##%  endpoint=586,626
##%  fgcolor=0,0,0
##%  bgcolor=255,229,193
##%  fontname=Monospaced
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=27
##%  type=Label
##%  label=Key:
##%  varname=label5L
##%  startpoint=67,299
##%  endpoint=111,321
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=28
##%  type=TextField
##%  label=
##%  varname=delKeyTF
##%  startpoint=116,299
##%  endpoint=263,320
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=delete()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=31
##%  type=Button
##%  label=Delete
##%  varname=deleteB
##%  startpoint=194,321
##%  endpoint=263,343
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=delete()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=32
##%  type=Label
##%  label=Delete:
##%  varname=label7L
##%  startpoint=12,278
##%  endpoint=70,295
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=bold
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=33
##%  type=Label
##%  label=------------------------------------------------------------------------
##%  varname=label8L
##%  startpoint=13,263
##%  endpoint=312,276
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=34
##%  type=Button
##%  label=Make New Hashmap
##%  varname=newMapB
##%  startpoint=14,558
##%  endpoint=155,578
##%  fgcolor=0,0,0
##%  bgcolor=255,200,0
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=bold
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=newMap()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=35
##%  type=Label
##%  label=Size:
##%  varname=component7BL
##%  startpoint=162,558
##%  endpoint=205,577
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=bold
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=36
##%  type=TextField
##%  label=25
##%  varname=newSizeTF
##%  startpoint=206,558
##%  endpoint=285,579
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=newMap()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=38
##%  type=Label
##%  label=
##%  varname=msg1L
##%  startpoint=12,216
##%  endpoint=131,238
##%  fgcolor=255,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=39
##%  type=Button
##%  label=Fill in with sample
##%  varname=fillSampleB
##%  startpoint=14,602
##%  endpoint=164,622
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=makeSample()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=40
##%  type=Label
##%  label=
##%  varname=hashkey1L
##%  startpoint=264,76
##%  endpoint=311,98
##%  fgcolor=255,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=46
##%  type=Label
##%  label=Key:
##%  varname=label9L
##%  startpoint=67,381
##%  endpoint=112,403
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=47
##%  type=TextField
##%  label=
##%  varname=tempKeyTF
##%  startpoint=116,381
##%  endpoint=263,402
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=check()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=48
##%  type=Button
##%  label=Check
##%  varname=playHashKeyB
##%  startpoint=194,404
##%  endpoint=263,426
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=check()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=49
##%  type=Label
##%  label=Check hash:
##%  varname=label10L
##%  startpoint=12,360
##%  endpoint=102,377
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=bold
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=50
##%  type=Label
##%  label=------------------------------------------------------------------------
##%  varname=label11L
##%  startpoint=13,345
##%  endpoint=312,358
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=51
##%  type=Label
##%  label=
##%  varname=showKeyL
##%  startpoint=264,381
##%  endpoint=311,403
##%  fgcolor=255,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=52
##%  type=Label
##%  label=
##%  varname=findKeyL
##%  startpoint=264,191
##%  endpoint=311,213
##%  fgcolor=255,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=53
##%  type=Label
##%  label=
##%  varname=delKeyL
##%  startpoint=264,299
##%  endpoint=311,321
##%  fgcolor=255,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=54
##%  type=Label
##%  label=Percentage devoted to collisions:
##%  varname=component10BL
##%  startpoint=14,582
##%  endpoint=250,600
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=55
##%  type=TextField
##%  label=25%
##%  varname=pctCollisionsTF
##%  startpoint=252,582
##%  endpoint=285,601
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=56
##%  type=Label
##%  label=------------------------------------------------------------------------
##%  varname=label12L
##%  startpoint=13,427
##%  endpoint=312,440
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=62
##%  type=TextArea
##%  label=
##%  varname=keysTA
##%  startpoint=11,469
##%  endpoint=134,549
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=check()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=63
##%  type=Button
##%  label=All Keys
##%  varname=getKeysB
##%  startpoint=11,445
##%  endpoint=80,467
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=showAllKeys()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=65
##%  type=Button
##%  label=All Values
##%  varname=getAllValuesB
##%  startpoint=168,445
##%  endpoint=237,467
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=showAllValues()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=66
##%  type=TextArea
##%  label=
##%  varname=valuesTA
##%  startpoint=168,469
##%  endpoint=291,549
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=check()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=67
##%  type=Label
##%  label=
##%  varname=numKeysL
##%  startpoint=87,445
##%  endpoint=135,467
##%  fgcolor=0,0,255
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=68
##%  type=Label
##%  label=
##%  varname=numValuesL
##%  startpoint=244,445
##%  endpoint=292,467
##%  fgcolor=0,0,255
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=69
##%  type=Button
##%  label=Info
##%  varname=infoB
##%  startpoint=230,603
##%  endpoint=286,623
##%  fgcolor=0,0,0
##%  bgcolor=119,229,175
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=bold
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=popup(myhashmap.info())
##%  codeItem=
##%END
##%COMPONENT 
##%  id=70
##%  type=Button
##%  label=Clear
##%  varname=clearB
##%  startpoint=178,602
##%  endpoint=219,623
##%  fgcolor=255,255,0
##%  bgcolor=255,0,0
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=bold
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=myhashmap.clear()\ndisplay()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=71
##%  type=Label
##%  label=Command stream:
##%  varname=component11BL
##%  startpoint=588,54
##%  endpoint=698,78
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=9
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=72
##%  type=TextArea
##%  label=
##%  varname=commandsTA
##%  startpoint=588,80
##%  endpoint=869,386
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=73
##%  type=Button
##%  label=Run all
##%  varname=runallB
##%  startpoint=777,54
##%  endpoint=830,78
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=runall()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=74
##%  type=Button
##%  label=Load
##%  varname=loadB
##%  startpoint=831,54
##%  endpoint=874,78
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=loadCommands()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=75
##%  type=TextField
##%  label=
##%  varname=filenameTF
##%  startpoint=589,388
##%  endpoint=813,410
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=8
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=76
##%  type=Label
##%  label=Results:
##%  varname=component16BL
##%  startpoint=588,415
##%  endpoint=658,437
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=77
##%  type=TextArea
##%  label=
##%  varname=resultsTA
##%  startpoint=589,439
##%  endpoint=868,626
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=78
##%  type=Button
##%  label=Save
##%  varname=saveB
##%  startpoint=815,388
##%  endpoint=869,410
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=10
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=saveCommands()
##%  codeItem=
##%END
##%COMPONENT 
##%  id=80
##%  type=Label
##%  label=The hashmap: * indicates overflow area
##%  varname=component17BL
##%  startpoint=312,55
##%  endpoint=586,77
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=9
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=
##%  codeItem=
##%END
##%COMPONENT 
##%  id=81
##%  type=Choice
##%  label=Select sample
##%  varname=getSampleCH
##%  startpoint=700,55
##%  endpoint=776,77
##%  fgcolor=0,0,0
##%  bgcolor=255,255,0
##%  fontname=SansSerif
##%  fontsize=8
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=sample_var
##%  other=sample1\nsample2
##%  codeAction=
##%  codeItem=showSample(gettext(getSampleCH))
##%END
##%COMPONENT 
##%  id=82
##%  type=Button
##%  label=Run selected
##%  varname=runselectedB
##%  startpoint=758,412
##%  endpoint=869,434
##%  fgcolor=0,0,0
##%  bgcolor=255,255,255
##%  fontname=SansSerif
##%  fontsize=9
##%  fontstyle=plain
##%  samebgcolor=1
##%  fixedx=0
##%  fixedy=0
##%  resizable=1
##%  filename=
##%  scrollbar_isHorizontal=true
##%  list_rowsMultiselect=false
##%  minval=1
##%  maxval=100
##%  startingval=50
##%  rescaleImage=1
##%  moreoptions=
##%  assocvarname=Button1_var
##%  other=
##%  codeAction=text = commandsTA.text.get(SEL_FIRST, SEL_LAST)\nrunOne(text)\n
##%  codeItem=
##%END
##%ENDCOMPONENTS


####END